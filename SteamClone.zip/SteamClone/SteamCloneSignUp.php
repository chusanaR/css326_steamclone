<!DOCTYPE html>
<html>
<head>
<title>STEAMCLONE</title>
</div>
  <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>

<div class="login">
    <a href="SteamClone.php"><h2 class="nonactive"> SIGN IN </h2></a>
    <a href="SteamCloneSignUp.php"><h2 class="active">SIGN UP </h2></a>
<style>
 
    
</style>
<link rel="stylesheet" href="SteamCloneLogin.css">
</head>
<body>


<div id="wrapper"> 
	<div id="div_header">
		STEAMCLONE
	</div>
    
	
    <br>  <br>  <br>   <br>
    <h5><input type="text" class="text" name="email">
     <span>Email</span>

    <br>
    <input type="text" class="text" name="username">
     <span>Username</span>

    <br>
    

    <input type="password" class="text" name="password">
    <span>Password</span>
    <br>
    <input type="text" class="text" name="firstname">
     <span>Firstname</span>
    <br>
    <input type="text" class="text" name="lastname">
     <span>Lastname</span>
    <br>
    <input type="text" class="text" name="accountid">
     <span>Account ID</span>
    <br>
    <input type="text" class="text" name="dob">
     <span>Date Of Birth</span>
    <br>
    <input type="text" class="text" name="sa">
     <span>Street Address</span>
    <br>
    <input type="text" class="text" name="cuty">
     <span>City</span>
    <br>
    <input type="text" class="text" name="country">
     <span>Country</span>
    <br>


    
    <button class="createaccount">
      Create Account
    </button>


    <hr>

    <a href="#">Forgot Password?</a>
  </form>
</h5>

</div>
</body>
</html>



