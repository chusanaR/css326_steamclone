<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
button {
  border: 50%;
  color: black;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 200px;
  margin: 4px 2px;
  cursor: pointer;
}

.button1 {background-color: #256D85;} /* Green */
.button1 {border-radius: 6px;
    text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 25px;
  margin: 4px 2px;
  cursor: pointer;}


 .button2 {background-color: #06283D;} /* Blue */
 .button2 {border-radius: 6px;
    text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 25px;
  margin: 4px 2px;
  cursor: pointer;}
body {
  font-family: Arial;
  color: white;
}

.split {
  height: 100%;
  width: 50%;
  position: fixed;
  z-index: 1;
  top: 0;
  overflow-x: hidden;
  padding-top: 20px;
}

.left {
  left: 0;
  background-color: #00008B;
}

.right {
  right: 0;
  background-color: #33BEFF;
}

.centered {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  text-align: center;
}

.centered img {
  width: 650px;
  border-radius: 5%;
}
</style>
</head>
<body>

<div class="split left">
  <div class="centered">
    <img src="store_home.jpg" alt="Store">
    <h2>Welcome to SteamClone Store</h2>
    <button1 class="button1">Go to Store</button1>
    <p>Buy and download many game here</p>
  </div>
</div>

<div class="split right">
  <div class="centered">
    <img src="developer_home.jpg" alt="Developer">
    <h2>Become a game developer</h2>
    <button2 class="button2">Publish Your game</button2>
    <p>Create game developer and upload your game</p>
  </div>
</div>
     
</body>
</html> 