
<!DOCTYPE html>
<html>
<head>
<title>STEAMCLONE</title>

<link rel="stylesheet" href="SteamCloneLogin.css">
</head>
<body>



	</div>
  <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet' type='text/css'>

<div class="login">
 

   <a href="SteamClone.php"><h2 class="active"> SIGN IN </h2></a>
    <a href="SteamCloneSignUp.php"><h2 class="nonactive">SIGN UP </h2></a>
  <form>
   
    <input type="text" class="text" name="username">
     <span>username</span>
    <br>
    <br>

    <input type="password" class="text" name="password">
    <span>password</span>
    <br>

    <input type="checkbox" id="checkbox-1-1" class="custom-checkbox" />
    <label for="checkbox-1-1">Keep me Signed in</label>
    
    <button class="signin">
    <a href="SSCplit.php"> Sign In</a>
    </button>


    <hr>

    <a href="#">Forgot Password?</a>
  </form>

</div>